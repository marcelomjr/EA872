Lab 02:
Aluno: Marcelo Martimiano Junior RA: 156531

-> Alterei o update dos corpos para que eles executem um movimento harmônico
amortecido.

-> Alterei o update de tela para exibir os corpos como se fossem uma caixa
pressa a uma mola.

-> Crei as funções auxiliares para pegar as variáveis privadas do corpo.

-> Alterei o construtor do Corpo.

-> É possível alterar as constantes elásticas da mola e de amortecimento do
sistema na linha 21 do programa model_mainloop.cpp
